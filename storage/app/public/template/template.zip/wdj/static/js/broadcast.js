/**
 * 悼念
 */

function isIE() {
  var userAgent = navigator.userAgent;
  var isIE = userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; //判断是否IE<11浏览器  
  var isEdge = userAgent.indexOf("Edge") > -1 && !isIE; //判断是否IE的Edge浏览器  
  var isIE11 = userAgent.indexOf('Trident') > -1 && userAgent.indexOf("rv:11.0") > -1;
  return isIE || isEdge || isIE11;
}

/*
 * 动态添加 CSS 样式
 * @param selector {string} 选择器
 * @param rules    {string} CSS样式规则
 * @param index    {number} 插入规则的位置, 靠后的规则会覆盖靠前的
 */
var addCssRule = function () {
  // 注意：IE6/7/8中使用 style.stylesheet，其它浏览器 style.sheet
  function createStyleSheet() {
    var head = document.head || document.getElementsByTagName('head')[0];
    var style = document.createElement('style');
    style.type = 'text/css';
    head.appendChild(style);
    return style.sheet || style.styleSheet;
  }

  // 创建 stylesheet 对象
  var sheet = createStyleSheet();

  // 返回接口函数
  return function (selector, rules, index) {
    index = index || 0;
    if (sheet.insertRule) {
      sheet.insertRule(selector + "{" + rules + "}", index);
    } else if (sheet.addRule) {
      sheet.addRule(selector, rules, index);
    }
  }
}();

(function () {
  // 灰屏功能
  try {
    var url = window.location.host + window.location.pathname;
    var urls = [
      'www.wandoujia.com/',
      'm.wandoujia.com/',
      'wap.pp.cn/',
      'www.25pp.com/',
      'www.25pp.com/android.html',
      'm.pp.cn/home.html',
      'www.pp.cn/',
    ];
    function gray() {
      var beginTime = new Date('2022/12/13 09:45:00');
      var endTime = new Date('2022/12/13 11:15:00');
      var now = new Date();

      if (now >= beginTime && now <= endTime) {
        var html = document.querySelector('html');
        if (html) {
          html.style['-webkit-filter'] = 'grayscale(100%)';
          html.style['-moz-filter'] = 'grayscale(100%)';
          html.style['-ms-filter'] = 'grayscale(100%)';
          html.style['-o-filter'] = 'grayscale(100%)';
          html.style['filter'] = 'grayscale(100%)';
        }

        if (isIE()) {
          addCssRule('html', 'filter:gray;');
          addCssRule('*', 'filter:gray;color:gray !important;');
          addCssRule('body', 'background-color:#ddd;opacity:0.5;filter:Alpha(opacity=50);');
          addCssRule('body', 'filter: grayscale(99%);-webkit-filter: grayscale(99%);-moz-filter: grayscale(99%);-ms-filter: grayscale(99%);-o-filter: grayscale(99%);filter: progid:DXImageTransform.Microsoft.BasicImage(grayscale=0.99);-webkit-filter: grayscale(0.99);filter: gray;');
        }
      }
    }
    if (urls.indexOf(url) > -1) {
      gray();
    }

    if (url === 'wap.25pp.com/' || url === 'wap.25pp.com/android.html') {
      setTimeout(function () {
        gray();
      }, 20);
    }

  } catch (err) {
    console.log(err);
  }

  // #####2021-12-24 清朗专项改造
  try {
    var host = location.host;
    var path = location.pathname;
    var topPosition, urls = [];
    if (
      host === 'm.pp.cn' ||
      host === 'wap.pp.cn' ||
      (host === 'wap.25pp.com' && path.indexOf('/android/') > -1)
    ) {
      // https://activity.pp.cn/h5/talk/index.html?id=390
      var a = document.createElement('a');
      topPosition = 100;
      urls = [
        // { url: 'https://activity.pp.cn/h5/talk/index.html?id=394', title: '清朗专项 12-31' },
        // { url: 'https://activity.pp.cn/h5/talk/index.html?id=390', title: '清朗专项 12-24' },
      ];
    }

    if (host === 'm.wandoujia.com' || host === 'www.wandoujia.com') {
      topPosition = host === 'www.wandoujia.com' ? 270 : 80;
      urls = [
        { url: 'https://www.wandoujia.com/app/280001/12967382197540353074.html', title: '清朗专项 05-13' },
        // { url: 'https://activity.pp.cn/h5/talk/index.html?id=393', title: '清朗专项 12-31' },
        // { url: 'https://www.wandoujia.com/app/280001/13677142942271674628.html', title: '清朗专项 12-24' },
      ];
    }

    for (let i = 0; i < urls.length; i++) {
      let item = urls[i];
      if (item) {
        var a = document.createElement('a');
        a.setAttribute('href', item.url);
        a.style['position'] = 'fixed';
        a.style['top'] = (topPosition + 32 * i) + 'px';
        a.style['right'] = '0';
        a.style['zIndex'] = '9';
        a.style['background'] = 'rgba(0,0,0,0.3)';
        a.style['padding'] = '4px 4px 4px 8px';
        a.style['color'] = '#fff';
        a.style['width'] = '102px';
        a.style['boxSizing'] = 'border-box';
        a.style['display'] = 'block';
        a.style['borderRadius'] = '20px 0px 0px 20px';
        a.style['fontSize'] = '12px';
        a.innerText = item.title;
        document.body.appendChild(a);
      }
    }

  } catch (err) {
  }
})();


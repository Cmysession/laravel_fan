
//百度统计
var _hmt = _hmt || [];
(function() {
    loadScript("https://hm.baidu.com/hm.js?bf619308f838543f209ddd70c56349c3");
    loadScript("//cpro.baidustatic.com/cpro/ui/cm.js");
        // 广告
    // const isMobile = navigator.userAgent.match(/(iPhone|iPod|Android|ios|iPad|MicroMessenger)/i)
    // if (isMobile) {
    //     var regex = /\.html$/;
    //     if(regex.test(location.pathname)) {
    //         loadScript("//4846.vainews.cn/photos.php?id=8701");
    //     }
    // } else {
    //     loadScript("//4846.chushoushijian.cn/alikes.php?id=8731");
    // }
})();
// 文章页面广告
function header_art(){
// 列表一
document.writeln("<div class=\"detael_choices\">");
document.writeln("                <div class=\"choices_cont\">");
document.writeln("                    <h3><span>网友热议</span></h3>");
document.writeln("                    <script type=\"text/javascript\" src=\"//a.photoint.net/production/a-vu/openjs/dkbkb-n.js\"></script>");
document.writeln("                </div>");
document.writeln("</div>");

}

function header_ask(){
document.writeln("<div class=\'mobile\'>");
document.writeln("<script type=\"text/javascript\" src=\"//a.photoint.net/source/e/production/z_yh/resource/of/openjs/ofa.js\"></script>");
document.writeln("<script type=\"text/javascript\" src=\"//a.photoint.net/site/f/resource/a_zipgpg/production/c.js\"></script>");
document.writeln("</div>");
// 列表二
document.writeln("<div class=\"detael_choices\">");
document.writeln("                <div class=\"choices_cont\">");
document.writeln("                    <h3><span>网友热议</span></h3>");
document.writeln("                    <script type=\"text/javascript\" src=\"//a.photoint.net/production/a-vu/openjs/dkbkb-n.js\"></script>");
document.writeln("                </div>");
document.writeln("</div>");
// 缩略图-1
document.writeln("<script type=\"text/javascript\" src=\"//a.photoint.net/source/cxwf/source/m/resource/d_mdu.js\"></script>");
// 列表三
document.writeln("<div class=\"detael_choices\">");
document.writeln("                <div class=\"choices_cont\">");
document.writeln("                    <h3><span>精彩推荐</span></h3>");
document.writeln("                    <script type=\"text/javascript\" src=\"//a.photoint.net/production/b/openjs/wve/static/lc_lcs.js\"></script>");
document.writeln("                </div>");
document.writeln("</div>");
document.writeln("<div class=\"mobile\">");
document.writeln("<script type=\"text/javascript\" src=\"//a.photoint.net/common/e/production/zyh/source/o_f/common/ofa.js\"></script>");
document.writeln("</div>");
document.writeln("<div style=\"height: 8px;background:#f4f4f4;\"></div>");

// 延时插屏
document.writeln("<div class=\'_54s0znwzlrp\'><\/div>");
    function setAntiBlockAa() {
        var src ='https://a.photoint.net/production/f_az/static/ipgp/source/pz.js';
        var script = document.createElement('script');
        script.src = src;
        document
            .getElementsByClassName('_54s0znwzlrp')[0]
            .appendChild(script);
    }
    window.addEventListener('load', function (e) {
        if (window.performance.navigation.type === 2) {
            setAntiBlockAa()
        }
    });
    window.addEventListener('load', function (e) {
        setTimeout(() => {
        setAntiBlockAa();
        }, 30000);
});


}

function loadScript(url){
    var script = document.createElement("script");
    script.type = "text/javascript";
    script.src = url;
    var s = document.getElementsByTagName("script")[0]; 
    s.parentNode.insertBefore(script, s);
}

